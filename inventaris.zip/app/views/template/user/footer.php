


</div>
<!-- Argon Scripts -->
<script src="<?= BASEURL ?>/vendor/jquery/jquery.min.js"></script>
<script src="<?= BASEURL ?>/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= BASEURL ?>/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= BASEURL ?>/vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= BASEURL ?>/vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="<?= BASEURL ?>/vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?= BASEURL ?>/vendor/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?= BASEURL ?>/vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?= BASEURL ?>/vendor/datatables.net-select/js/dataTables.select.min.js"></script>
<script src="<?= BASEURL ?>/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASEURL ?>/vendor/js-cookie/js.cookie.js"></script>
<script src="<?= BASEURL ?>/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
<script src="<?= BASEURL ?>/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
<script src="<?= BASEURL ?>/vendor/chart.js/dist/Chart.min.js"></script>
<script src="<?= BASEURL ?>/vendor/chart.js/dist/Chart.extension.js"></script>
<script src="<?= BASEURL ?>/vendor/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script src="<?= BASEURL ?>/js/argon.min9f1e.js?v=1.1.0"></script>
<script src="<?= BASEURL ?>/js/script-card.js"></script>
<script src="<?= BASEURL ?>/js/push/push.js"></script>
<script src="<?= BASEURL ?>/js/push/serviceWorker.min.js"></script>
<script src="<?= BASEURL ?>/vendor/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="<?= BASEURL ?>/js/script_user.js"></script>
<script src="<?= BASEURL ?>/js/script.js"></script>


</body>
</html>