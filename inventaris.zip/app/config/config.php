<?php

define('BASE_URL', 'http://localhost/Inventaris_skensa');
define('BASEURL', 'http://localhost/Inventaris_skensa/public');

//DB
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_inventaris');
